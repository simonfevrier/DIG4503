declare module 'react-native' {
  declare module.exports: {
    StyleSheet: {
      create: Function
    }
  }
}
