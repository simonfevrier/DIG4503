// flow-typed signature: 28fdff7f110e1c75efab63ff205dda30
// flow-typed version: c6154227d1/flow-bin_v0.x.x/flow_>=v0.104.x

declare module "flow-bin" {
  declare module.exports: string;
}
