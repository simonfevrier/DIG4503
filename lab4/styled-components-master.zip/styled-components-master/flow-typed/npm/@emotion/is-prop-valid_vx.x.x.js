declare module '@emotion/is-prop-valid' {
  declare module.exports: string => boolean
}
