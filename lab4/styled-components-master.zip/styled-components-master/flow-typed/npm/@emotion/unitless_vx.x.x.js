declare module '@emotion/unitless' {
  declare module.exports: { [key: string]: 1 }
}
