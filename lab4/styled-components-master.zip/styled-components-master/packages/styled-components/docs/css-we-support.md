**The documentation has been moved to [styled-components.com](https://www.styled-components.com/docs/api#supported-css), please update your bookmarks!**
