**The documentation has been moved to [styled-components.com](https://www.styled-components.com/docs/advanced#security), please update your bookmarks!**
