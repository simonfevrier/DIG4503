import { View } from 'react-native';
export default View;
